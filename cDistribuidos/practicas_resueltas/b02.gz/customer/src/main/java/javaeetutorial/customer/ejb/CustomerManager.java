/**
 * Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
 *
 * You may not modify, use, reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * http://java.net/projects/javaeetutorial/pages/BerkeleyLicense
 */
package javaeetutorial.customer.ejb;

import java.io.Serializable;
import java.util.List;
import java.util.logging.Logger;
import javaeetutorial.customer.data.Customer;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Model;

/**
 *
 * @author ievans
 */
@Model
@ManagedBean
@SessionScoped
public class CustomerManager implements Serializable {
    private Customer customer;
    private List<Customer> customers;
    private boolean borrar;
    private static final Logger logger = Logger.getLogger(CustomerManager.class.getName());
    @EJB
    private CustomerBean customerBean;
    
    @PostConstruct
    private void init() {
        logger.info("new customer created");
        customer = new Customer();
        logger.info("id1:"+customer.getId()+"  =");
    
            setCustomers(customerBean.retrieveAllCustomers());
    
    }
    
    

   
    /**
     * @return the customer
     */
    public Customer getCustomer() {
        logger.info("id2:"+customer.getId());
        return customer;
    }

    /**
     * @param customer the customer to set
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
        logger.info("set "+customer.getId());
    }

    /**
     * @return the customers
     */
    public List<Customer> getCustomers() {
        return customerBean.retrieveAllCustomers();
    }
    
      /**
     * @param customers the customers to set
     */
    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
    
    public void deleteCustomer(int id){        
        customerBean.deleteCustomer(id);
    }

    public String updateCustomer(Customer customer){
        logger.info("manager id:"+customer.getId());
        this.customer=customer;
        return "customerRetrieved";
    }
    
    public String newCustomer(){
        this.customer=new Customer();
        return "index";
    }
}
