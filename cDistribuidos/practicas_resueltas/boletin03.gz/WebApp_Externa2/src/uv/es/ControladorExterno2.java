package uv.es;

import java.io.IOException;
import java.util.Vector;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uv.dbcd.ConsultaAutores;

/**
 * Servlet implementation class ControladorExterno2
 */
@WebServlet(name="ControladorExterno",urlPatterns = { "/Controlador", "/Autores" })
public class ControladorExterno2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB(lookup="java:global/EjemploEAR/EjemploEAR_EJB/ConsultaAutores!es.uv.dbcd.ConsultaAutores")
    private ConsultaAutores consulta;
	
    public ControladorExterno2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpSession = request.getSession(true);
		//ConsultaAutoresRemote consulta = (ConsultaAutoresRemote) httpSession.getAttribute("mi_bean");
		
		if (consulta == null) {
			try {
				InitialContext ic = new InitialContext();
				consulta = (ConsultaAutores) ic.lookup("AutoresBO");
				
			} catch (NamingException e) {
				throw new ServletException(e);
			}
		}
		Vector<String> autoresYUsuario=consulta.getAutoresYUsuario();		
		System.out.println("Autores: " + autoresYUsuario);
		request.setAttribute("autores", autoresYUsuario);
		
		
		request.getRequestDispatcher("/autores.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
