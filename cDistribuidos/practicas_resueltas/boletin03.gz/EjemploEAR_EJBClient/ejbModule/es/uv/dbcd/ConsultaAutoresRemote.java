package es.uv.dbcd;

import java.util.Vector;

import javax.ejb.Remote;

@Remote
public interface ConsultaAutoresRemote {
	 public Vector<String> getAutores();
	 //añadido para sacar nombre de usuario
	 public Vector<String> getAutoresYUsuario();
	 public void setUserName(String userName);

}
