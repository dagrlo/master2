package es.uv.dbcd;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSRuntimeException;
import javax.jms.Queue;
import javax.sql.DataSource;

import uv.es.AuxiliarBeanLocal;
import uv.es.UtilsBean;

/**
 * Session Bean implementation class ConsultaAutores
 */


//lo quitamos. deberia ir en modo stateless
// si se pone como stateful no añade el nombre a la lista
// lo de mappedName se añade por el controladorusuario que lo llama con este nombre
 //@Stateless (mappedName = "AutoresBO")
@Stateful(mappedName = "AutoresBO")
// con su nombre
@LocalBean
public class ConsultaAutores implements ConsultaAutoresRemote {

	@Inject
	@JMSConnectionFactory("jms/factoriaConexiones")
	private JMSContext context;
	@Resource(lookup="jms/webappQueue")
	private Queue queue;
	
	// Solicitamos la inyección de un recurso
	@Resource(lookup = "jdbc/librospool")
	private DataSource bd;
	private Vector<String> autores = null;
	private String userName = null;
	
	@EJB
	private AuxiliarBeanLocal auxiliar;
	
	@EJB
	private UtilsBean utils;

	public ConsultaAutores() {
		autores = new Vector<String>();
		userName = "No definido";
	}

	@PostConstruct
	public void inicia() {
		try {
			Connection con = bd.getConnection();
			String consulta = "SELECT AU_LNAME, AU_FNAME FROM authors;";
			ResultSet rs = con.createStatement().executeQuery(consulta);
			rs.beforeFirst();
			while (rs.next()) {
				autores.add(rs.getString(1) + " " + rs.getString(2));
			}
			rs.close();
			con.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		autores.add(auxiliar.getAutorInventado());
	}

	@Override
	public Vector<String> getAutores() {
		return autores;
	}

	@Override
	public Vector<String> getAutoresYUsuario() {
		System.out.println("get:"+this.userName);
		Vector<String> autoresYUsuario = new Vector<String>();
		autoresYUsuario.addAll(autores);
		autoresYUsuario.add(userName);
		autoresYUsuario.add("fecha:"+utils.getDate().getTime()+"  hits:"+utils.getHits());
		
		return autoresYUsuario; 
	}

	@Override
	public void setUserName(String userName) {
		this.userName = userName;
		try{
			String text="Usuario: "+userName;
			context.createProducer().send(queue, text);		
			System.out.println("consulta setusr:"+text+" /"+this.userName);
		} catch(JMSRuntimeException t){
			t.printStackTrace();
		}
	}

}
