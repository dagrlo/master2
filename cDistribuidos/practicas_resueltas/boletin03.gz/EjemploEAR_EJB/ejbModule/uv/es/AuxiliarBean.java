package uv.es;

import javax.ejb.Asynchronous;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class AuxiliarBean
 */
@Stateless
@LocalBean

public class AuxiliarBean implements AuxiliarBeanLocal {

    /**
     * Default constructor. 
     */
    public AuxiliarBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String getAutorInventado() {
		String nombreAutor="AUTOR INVENTADO";
		
		return nombreAutor;
	}

}
