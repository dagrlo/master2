package uv.es;

import javax.ejb.Local;

@Local
public interface AuxiliarBeanLocal {
	public String getAutorInventado();
}
