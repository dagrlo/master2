package es.uv.dbcd2;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uv.dbcd.ConsultaAutoresRemote;

/**
 * Servlet implementation class ControladorUsuario2
 */
@WebServlet("/GetUserName2")
public class ControladorUsuario2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControladorUsuario2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpSession = request.getSession(true);
		ConsultaAutoresRemote consulta2 = (ConsultaAutoresRemote) httpSession.getAttribute("mi_bean");
		
		if (consulta2 == null) {
			try {
				InitialContext ic = new InitialContext();
				consulta2 = (ConsultaAutoresRemote) ic.lookup("AutoresBO");				
				httpSession.setAttribute("mi_bean", consulta2);
			} catch (NamingException e) {
				throw new ServletException(e);
			}
		}
		String nombre = request.getParameter("nombre");
		consulta2.setUserName(nombre);
		request.setAttribute("nombre", nombre);
		request.getRequestDispatcher("./index.jsp").forward(request, response);
	}

}
