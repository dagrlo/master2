package uv.es;

import java.io.IOException;
import java.util.Vector;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uv.dbcd.ConsultaAutores;

/**
 * Servlet implementation class ControladorExterno
 */
@WebServlet(name="ControladorExterno",urlPatterns = { "/Controlador", "/Autores" })
public class ControladorExterno extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    @EJB(lookup="java:global/EjemploEAR/EjemploEAR_EJB/ConsultaAutores!es.uv.dbcd.ConsultaAutores")
    private ConsultaAutores consulta;
	
    public ControladorExterno() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Vector<String> autores = consulta.getAutores();
		System.out.println("Autores: " + autores);
		request.setAttribute( "autores", autores ) ;
		request.getRequestDispatcher ( "/autores.jsp").forward (request, response) ;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
