package es.uv.dbcd;

import java.io.IOException;
import java.util.Vector;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Controlador
 */
//comentado para usar la configuracion en web.xml

//@WebServlet(name = "Controlador", urlPatterns = { "/Controlador", "/Autores" })

public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	// Solicitamos la inyección de un EJB
	//@EJB
	//private ConsultaAutoresRemote consulta;   //ACCEDE MEDIANTE interfaz a consultaautores
	//@EJB
	//private ConsultaAutores consulta;   //ACCEDE SIN interfaz a consultaautores

	public Controlador() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		//Ahora se accede a la consulta de esta forma para poder leer el nombre de usuario
		//cargado en controladorusuario. Si se hace como estaba saldra como no definido
		HttpSession httpSession = request.getSession(true);
		ConsultaAutoresRemote consulta = (ConsultaAutoresRemote) httpSession
				.getAttribute("mi_bean");
		
		if (consulta == null) {
			try {
				InitialContext ic = new InitialContext();
				consulta = (ConsultaAutoresRemote) ic.lookup("AutoresBO");
				
			} catch (NamingException e) {
				throw new ServletException(e);
			}
		}
		Vector<String> autoresYUsuario=consulta.getAutoresYUsuario();		
		System.out.println("Autores: " + autoresYUsuario);
		request.setAttribute("autores", autoresYUsuario);
		
		
		request.getRequestDispatcher("/autores.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
