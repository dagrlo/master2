package es.uv.dbcd;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: BeanMensaje
 */
@MessageDriven(
		activationConfig={
				@ActivationConfigProperty(
						propertyName="destinationType",propertyValue="javax.jms.Queue"),
				@ActivationConfigProperty(
						propertyName="destinationLookup",propertyValue="jms/webappQueue")
						
		},mappedName="jms/webappQueue")
		
public class BeanMensaje implements MessageListener {

    /**
     * Default constructor. 
     */
    public BeanMensaje() {
        // TODO Auto-generated constructor stub
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) {
        
        try{
        	if (message instanceof TextMessage){
        		String s=((TextMessage)message).getText();
        		System.out.println("Mensaje recibido--> "+s);
        	}
        } catch (JMSException e){
        	e.printStackTrace();
        }
        
    }

}
