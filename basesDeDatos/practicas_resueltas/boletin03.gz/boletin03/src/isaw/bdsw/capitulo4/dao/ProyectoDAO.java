package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Proyecto;



public interface ProyectoDAO {
	public void insert(Proyecto p);
	public Proyecto read(Proyecto p);
	public void update(Proyecto p);
	public void delete(Proyecto p);
}
