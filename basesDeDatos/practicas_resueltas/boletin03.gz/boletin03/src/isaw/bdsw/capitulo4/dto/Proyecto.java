package isaw.bdsw.capitulo4.dto;

public class Proyecto {
	private int idProyecto;
	private String nombre;
	private String nombreClave;
	private int departamento;
	private int responsable;
	private int proPrincipal;	
	
	public Proyecto() {
		this.idProyecto = 0;
		this.nombre = "";
		this.nombreClave = "";
		this.departamento = 0;
		this.responsable = 0;
		this.proPrincipal = 0;
	}

	public Proyecto(int idProyecto, String nombre, String nombreClave,
			int departamento, int responsable, int proPrincipal) {
		this.idProyecto = idProyecto;
		this.nombre = nombre;
		this.nombreClave = nombreClave;
		this.departamento = departamento;
		this.responsable = responsable;
		this.proPrincipal = proPrincipal;
	}

	public int getIdProyecto() {
		return idProyecto;
	}

	public void setIdProyecto(int idProyecto) {
		this.idProyecto = idProyecto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNombreClave() {
		return nombreClave;
	}

	public void setNombreClave(String nombreClave) {
		this.nombreClave = nombreClave;
	}

	public int getDepartamento() {
		return departamento;
	}

	public void setDepartamento(int departamento) {
		this.departamento = departamento;
	}

	public int getResponsable() {
		return responsable;
	}

	public void setResponsable(int responsable) {
		this.responsable = responsable;
	}

	public int getProPrincipal() {
		return proPrincipal;
	}

	public void setProPrincipal(int proPrincipal) {
		this.proPrincipal = proPrincipal;
	}
	
	

}
