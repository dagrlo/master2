package isaw.bdsw.capitulo4.run;

import isaw.bdsw.capitulo4.dao.DAOFactory;
import isaw.bdsw.capitulo4.dao.DepartamentoDAO;
import isaw.bdsw.capitulo4.dao.EmpleadoDAO;
import isaw.bdsw.capitulo4.dao.ProyectoDAO;
import isaw.bdsw.capitulo4.dto.Departamento;
import isaw.bdsw.capitulo4.dto.Empleado;
import isaw.bdsw.capitulo4.dto.Proyecto;

import java.util.Date;

public class ProbarDAO {

	private static EmpleadoDAO eDAO;
	private static DepartamentoDAO dDAO;
	private static ProyectoDAO pDAO;
	private static Empleado e=new Empleado();
	private static Departamento d=new Departamento();
	private static Proyecto p=new Proyecto();
	
	public static void main(String[] args){
		DAOFactory dfactory=DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		eDAO=dfactory.getEmpleadoDAO();
		dDAO=dfactory.getDepartamentoDAO();
		pDAO=dfactory.getProyectoDAO();
		System.out.println("Probando EmpleadoDAO\n");
		System.out.println("\nLeyendo empleados 7,24,33 y 51:\n");
		muestraEmpleado(7,"","");
		muestraEmpleado(24,"","");
		muestraEmpleado(33,"","");
		muestraEmpleado(51,"","");		
		System.out.println("\nInsertando empleados nuevos...\n");	
		Date ahora = new Date();   
		//ES IMPOSIBLE PONER INT=NULL. Ademas en la BD esta definido como NULL=NO. Pongo departamento=1
		Empleado e1=new Empleado(0,"David","Grau López",1,ahora,"Rey",(short)30,100000.0,100000.0);
		Empleado e2=new Empleado(0,"Joaquin","Pascual",1,ahora,"nada",(short)10,1000.0,100.0);
		eDAO.insert(e1);
		eDAO.insert(e2);
		System.out.println("\nMostrando empleados nuevos:\n");
		int idE1=muestraEmpleado(0,"David","Grau López");
		int idE2=muestraEmpleado(0,"Joaquin","Pascual");
		System.out.println("\nModificando empleados...\n");
		e1.setIdEmpleado(idE1);
		e1.setDepartamento(2);
		e2.setIdEmpleado(idE2);
		e2.setDepartamento(2);
		eDAO.update(e1);
		eDAO.update(e2);
		muestraEmpleado(idE1,"","");
		muestraEmpleado(idE2,"","");
		System.out.println("\nBorrando empleados...\n");
		eDAO.delete(e1);
		eDAO.delete(e2);
		
		System.out.println("\nProbando DepartamentoDAO\n");
		System.out.println("\nLeyendo departamentos 1,3 y 5\n");
		muestraDepartamento(1,"");
		muestraDepartamento(3,"");
		muestraDepartamento(5,"");
		System.out.println("\nCreando nuevo departamento...\n");
		Departamento d1=new Departamento(0,"Siesta",20);
		dDAO.insert(d1);
		int dId=muestraDepartamento(0,"Siesta");
		System.out.println("\nCambiando manager...");
		d1.setManager(38);
		d1.setIdDepartamento(dId);
		dDAO.update(d1);
		muestraDepartamento(dId,"");
		System.out.println("Borrando departamento...");
		dDAO.delete(d1);
		
		System.out.println("\nProbando ProyectoDAO\n");
		System.out.println("\nLeyendo proyectos 2,4 y 6\n");
		muestraProyecto(2,"");
		muestraProyecto(4,"");
		muestraProyecto(6,"");
		System.out.println("\nCreando proyecto...\n");
		Proyecto p1=new Proyecto(0,"Estrella de la muerte","DS0001",4,39,3);
		pDAO.insert(p1);
		int p1Id=muestraProyecto(0,"Estrella de la muerte");
		System.out.println("Cambiando nombre clave del proyecto...");
		p1.setIdProyecto(p1Id);
		p1.setNombreClave("EM0001");
		pDAO.update(p1);
		muestraProyecto(p1Id,"");
		System.out.println("\nBorrando proyecto...\n");
		pDAO.delete(p1);
		
	}
	
	private static int muestraProyecto(int idProyecto,String nombre){
		Proyecto resultado=new Proyecto();
		p.setIdProyecto(idProyecto);
		p.setNombre(nombre);
		resultado=pDAO.read(p);
		System.out.println("PROYECTO ["+resultado.getIdProyecto()+"]: "+resultado.getNombre());
		System.out.println("          Nombre clave:"+resultado.getNombreClave());
		System.out.println("          Departamento:"+resultado.getDepartamento()+"    Responsable:"+resultado.getResponsable());
		System.out.println("          Proyecto principal:"+resultado.getProPrincipal());
		System.out.println("======================================================================");
		return resultado.getIdProyecto();
	}
	
	private static int muestraDepartamento(int idDepartamento, String nombre){
		Departamento resultado=new Departamento();
		d.setIdDepartamento(idDepartamento);
		d.setNombre(nombre);
		resultado=dDAO.read(d);
		System.out.println("DEPARTAMENTO ["+resultado.getIdDepartamento()+"]: "+resultado.getNombre());
		System.out.println("              Manager:"+resultado.getManager());
		System.out.println("=======================================================================");
		return resultado.getIdDepartamento();
		
	}
		
	private static int muestraEmpleado(int idEmpleado,String nombre,String apellidos){
		Empleado resultado=new Empleado();
		e.setIdEmpleado(idEmpleado);
		e.setNombre(nombre);
		e.setApellidos(apellidos);
		resultado=eDAO.read(e);
		System.out.println("EMPLEADO ["+resultado.getIdEmpleado()+"]: "+resultado.getNombre()+" "+resultado.getApellidos());
		System.out.println("          Departamento:"+resultado.getDepartamento()+"\n          Fecha de contrato:"+resultado.getFechaContrato());
		System.out.println("          Puesto:"+resultado.getPuesto()+"\n          Nivel educacion:"+resultado.getNivelEducacion());
		System.out.println("          Sueldo:"+resultado.getSueldo()+"\n          Complemento:"+resultado.getComplemento());
		System.out.println("=======================================================================================");
		return resultado.getIdEmpleado();
	}
}
