package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Empleado;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQLEmpleadoDAO implements EmpleadoDAO {
	
	private String insertSQL="INSERT INTO empleados (idEmpleado,nombre,apellidos,"
			+ "departamento, fechaContrato,puesto,nivelEducacion, sueldo, complemento)"
			+ " VALUES(null,?,?,?,?,?,?,?,?)";
	private String readSQL="SELECT * FROM empleados WHERE idEmpleado=?";
	private String readSQL2="SELECT * FROM empleados WHERE nombre=? AND apellidos=?";
	private String updateSQL="UPDATE empleados set nombre=?, apellidos=?,departamento=?"
			+ ",fechaContrato=?,puesto=?,nivelEducacion=?,sueldo=?,complemento=? WHERE"
			+ " idEmpleado=?";
	private String deleteSQL="DELETE FROM empleados WHERE idEmpleado=?";
	private Connection conexion;
	
	
	public MySQLEmpleadoDAO(){
		MySQLDAOFactory factoria=(MySQLDAOFactory) DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		try {
			conexion=factoria.createConnection();
		} catch (Exception e) {			
			e.printStackTrace();
		}			
	}
	
	@Override
	public void insert(Empleado e) {
		try {
			PreparedStatement ps=conexion.prepareStatement(insertSQL);			
			ps.setString(1, e.getNombre());
			ps.setString(2, e.getApellidos());
			ps.setInt(3, e.getDepartamento());
			java.sql.Date sqlDate = new java.sql.Date(e.getFechaContrato().getTime());
			ps.setDate(4, sqlDate);
			ps.setString(5, e.getPuesto());
			ps.setShort(6, e.getNivelEducacion());
			ps.setDouble(7, e.getSueldo());
			ps.setDouble(8, e.getComplemento());
			ps.executeUpdate();
		} catch (SQLException e1) {		
			e1.printStackTrace();
		}

	}

	@Override
	public Empleado read(Empleado e) {
		ResultSet resultado;
		Empleado empleado=null;
		PreparedStatement ps;
				
		try {
			if ((e.getNombre().equals(""))&&(e.getApellidos().equals(""))){
				ps=conexion.prepareStatement(readSQL);
				ps.setInt(1, e.getIdEmpleado());	
			} else {
				ps=conexion.prepareStatement(readSQL2);
				ps.setString(1, e.getNombre());
				ps.setString(2, e.getApellidos());
			}
			
			resultado=ps.executeQuery();
			resultado.next();
			empleado=new Empleado(resultado.getInt("idEmpleado"),resultado.getString("nombre"),resultado.getString("apellidos"),
					resultado.getInt("departamento"),resultado.getDate("fechaContrato"),resultado.getString("puesto"),
					resultado.getShort("nivelEducacion"),resultado.getFloat("sueldo"),resultado.getFloat("complemento"));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return empleado;
	}

	@Override
	public void update(Empleado e) {
		try {
			PreparedStatement ps=conexion.prepareStatement(updateSQL);
			ps.setString(1, e.getNombre());
			ps.setString(2, e.getApellidos());
			ps.setInt(3, e.getDepartamento());
			java.sql.Date sqlDate = new java.sql.Date(e.getFechaContrato().getTime());
			ps.setDate(4, sqlDate);
			ps.setString(5, e.getPuesto());
			ps.setShort(6, e.getNivelEducacion());
			ps.setDouble(7, e.getSueldo());
			ps.setDouble(8, e.getComplemento());
			ps.setInt(9, e.getIdEmpleado());
			ps.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}
	
	@Override
	public void delete(Empleado e) {
		try {
			PreparedStatement ps=conexion.prepareStatement(deleteSQL);
			ps.setInt(1, e.getIdEmpleado());
			ps.executeUpdate();
		} catch (SQLException e1) {			
			e1.printStackTrace();
		}

	}

}
