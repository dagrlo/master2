package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Proyecto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQLProyectoDAO implements ProyectoDAO{
	
	private String insertSQL="INSERT INTO proyectos (idProyecto,nombre,nomclave,departamento,responsable,proPrincipal)"
			+ "VALUES(null,?,?,?,?,?)";
	private String readSQL="SELECT * FROM proyectos WHERE idProyecto=?";
	private String readSQL2="SELECT * FROM proyectos WHERE nombre=?";
	private String updateSQL="UPDATE proyectos SET nombre=?,nomclave=?,departamento=?,responsable=?,proPrincipal=? WHERE idProyecto=?";
	private String deleteSQL="DELETE FROM proyectos WHERE idProyecto=?";
	private Connection conexion;
	
	public MySQLProyectoDAO(){
		MySQLDAOFactory factoria=(MySQLDAOFactory) DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		try {
			conexion=factoria.createConnection();
		} catch (Exception e) {			
			e.printStackTrace();
		}			
	}
	
	@Override
	public void insert(Proyecto p) {
		try {
			PreparedStatement ps=conexion.prepareStatement(insertSQL);
			ps.setString(1, p.getNombre());
			ps.setString(2, p.getNombreClave());
			ps.setInt(3, p.getDepartamento());
			ps.setInt(4, p.getResponsable());
			ps.setInt(5, p.getProPrincipal());
			ps.executeUpdate();
		} catch (SQLException e) {		
			e.printStackTrace();
		}
		
	}

	@Override
	public Proyecto read(Proyecto p) {
		ResultSet resultado=null;
		Proyecto proyecto=null;
		PreparedStatement ps;
		

			try {
				if (p.getNombre().equals("")){
					ps=conexion.prepareStatement(readSQL);
					ps.setInt(1, p.getIdProyecto());					
				} else {
					ps=conexion.prepareStatement(readSQL2);
					ps.setString(1, p.getNombre());
				}
				resultado=ps.executeQuery();
				resultado.next();
				proyecto=new Proyecto(resultado.getInt("idProyecto"),resultado.getString("nombre"),resultado.getString("nomclave")
						,resultado.getInt("departamento"),resultado.getInt("responsable"),resultado.getInt("proPrincipal"));
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		return proyecto;
	}

	@Override
	public void update(Proyecto p) {
		try {
			PreparedStatement ps=conexion.prepareStatement(updateSQL);
			ps.setString(1, p.getNombre());
			ps.setString(2, p.getNombreClave());
			ps.setInt(3, p.getDepartamento());
			ps.setInt(4, p.getResponsable());
			ps.setInt(5, p.getProPrincipal());
			ps.setInt(6, p.getIdProyecto());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(Proyecto p) {
		try {
			PreparedStatement ps = conexion.prepareStatement(deleteSQL);
			ps.setInt(1, p.getIdProyecto());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
