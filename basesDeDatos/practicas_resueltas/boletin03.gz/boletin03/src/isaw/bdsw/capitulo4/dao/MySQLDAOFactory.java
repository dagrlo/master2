package isaw.bdsw.capitulo4.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLDAOFactory extends DAOFactory {
	public static final String DRIVER="com.mysql.jdbc.Driver";
	public static final String DBURL="jdbc:mysql://localhost/empresa";
	public static final String USERNAME="recursos";
	public static final String PASSWORD="recpwd";
	
	public static Connection createConnection() throws Exception {
		Class.forName(DRIVER).newInstance();
		return DriverManager.getConnection(DBURL, USERNAME, PASSWORD);
	}
	
	@Override
	public DepartamentoDAO getDepartamentoDAO(){
		return new MySQLDepartamentoDAO();
	}
	
	@Override
	public ProyectoDAO getProyectoDAO(){
		return new MySQLProyectoDAO();
	}
	
	@Override
	public EmpleadoDAO getEmpleadoDAO() {		
		return new MySQLEmpleadoDAO();
	}

}
