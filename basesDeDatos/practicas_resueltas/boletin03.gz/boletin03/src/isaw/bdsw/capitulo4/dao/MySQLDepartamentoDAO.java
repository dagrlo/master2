package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Departamento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQLDepartamentoDAO implements DepartamentoDAO{

	private String insertSQL="INSERT INTO departamentos (idDepartamento,nombre,manager)"
			+ "VALUES(null,?,?)";
	private String readSQL="SELECT * FROM departamentos WHERE idDepartamento=?";
	private String readSQL2="SELECT * FROM departamentos WHERE nombre=?";
	private String updateSQL="UPDATE departamentos SET nombre=?, manager=? WHERE idDepartamento=?";
	private String deleteSQL="DELETE FROM departamentos WHERE idDepartamento=?";
	private Connection conexion;
	
	public MySQLDepartamentoDAO(){
		MySQLDAOFactory factoria=(MySQLDAOFactory) DAOFactory.getDAOFactory(DAOFactory.MYSQL);
		try {
			conexion=factoria.createConnection();
		} catch (Exception e) {			
			e.printStackTrace();
		}			
	}
	
	@Override
	public void insert(Departamento d) {
		try {
			PreparedStatement ps=conexion.prepareStatement(insertSQL);
			ps.setString(1, d.getNombre());
			ps.setInt(2, d.getManager());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}

	@Override
	public Departamento read(Departamento d) {
		ResultSet resultado;
		Departamento departamento=null;
		PreparedStatement ps;
		
		try {
			if (d.getNombre().equals("")){
				ps=conexion.prepareStatement(readSQL);
				ps.setInt(1, d.getIdDepartamento());
			} else {
				ps=conexion.prepareStatement(readSQL2);
				ps.setString(1, d.getNombre());
			}
			
			resultado=ps.executeQuery();
			resultado.next();
			departamento=new Departamento(resultado.getInt("idDepartamento"),resultado.getString("nombre"),resultado.getInt("manager"));
		} catch (SQLException e) {		
			e.printStackTrace();
		}
		return departamento;
	}

	@Override
	public void update(Departamento d) {
		try {
			PreparedStatement ps=conexion.prepareStatement(updateSQL);
			ps.setString(1, d.getNombre());
			ps.setInt(2, d.getManager());
			ps.setInt(3, d.getIdDepartamento());
			ps.executeUpdate();
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(Departamento d) {
		PreparedStatement ps;
		try {
			ps = conexion.prepareStatement(deleteSQL);
			ps.setInt(1, d.getIdDepartamento());
			ps.executeUpdate();
		} catch (SQLException e) {	
			e.printStackTrace();
		}				
	}

}
