package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Empleado;

public interface EmpleadoDAO {
	public void insert(Empleado e);
	public Empleado read(Empleado e);
	public void update(Empleado e);
	public void delete(Empleado e);
}
