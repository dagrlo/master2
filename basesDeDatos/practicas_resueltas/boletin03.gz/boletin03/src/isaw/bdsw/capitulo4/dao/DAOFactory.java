package isaw.bdsw.capitulo4.dao;

public abstract class DAOFactory {
	// Lista de DAOs soportados
	public static final int ORACLE = 1;
	public static final int MYSQL = 2;
	public static final int XML = 3;
	
	public abstract EmpleadoDAO getEmpleadoDAO();
	public abstract DepartamentoDAO getDepartamentoDAO();
	public abstract ProyectoDAO getProyectoDAO();
	
	public static DAOFactory getDAOFactory(int which) {
		switch (which) {
		case MYSQL:
		return new MySQLDAOFactory();
		default:
		return null;
		}
	}
}
