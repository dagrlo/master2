package isaw.bdsw.capitulo4.dao;

import isaw.bdsw.capitulo4.dto.Departamento;

public interface DepartamentoDAO {
	public void insert(Departamento d);
	public Departamento read(Departamento d);
	public void update(Departamento d);
	public void delete(Departamento d);
}
