package es.uv.isaw.servlet;

import java.io.IOException;
import java.sql.Date;
import java.util.TreeMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uv.isaw.bo.DepartamentoBoRemote;
import es.uv.isaw.bo.EmpleadoBoRemote;

/**
 * Servlet implementation class EmpleadoNew
 */
@WebServlet("/EmpleadoNew")
public class EmpleadoNew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB(mappedName = "EmpleadoBo")
	private EmpleadoBoRemote empleadoBO;
	@EJB(mappedName = "DepartamentoBo")
	private DepartamentoBoRemote departamentoBO;

	public EmpleadoNew() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nombre, apellidos, puesto, ano, mes, dia;
		Date date;
		Short nivelEd = 0;
		float sueldo = 0, complemento = 0;
		int depto = 0;
		TreeMap<String, Integer> departamentos;
		Boolean error = false;

		String accion = request.getParameter("action");
		switch (accion) {
		case "form":
			departamentos = departamentoBO.keysDepartamento();
			request.setAttribute("departamentos", departamentos);
			request.getRequestDispatcher("/empleados/nuevoEmpleado.jsp")
					.forward(request, response);
			break;
		case "add":
			// Recogemos los áparmetros y comprobamos si son ávlidos
			nombre = request.getParameter("nombre");
			apellidos = request.getParameter("apellidos");
			puesto = request.getParameter("puesto");
			ano = request.getParameter("ano");
			mes = request.getParameter("mes");
			dia = request.getParameter("dia");
			date = Date.valueOf(ano + "-" + mes + "-" + dia);
			try {
				nivelEd = Short.parseShort(request
						.getParameter("nivelEducacion"));
				sueldo = Float.parseFloat(request.getParameter("sueldo"));
				complemento = Float.parseFloat(request
						.getParameter("complemento"));
				depto = Integer.parseInt(request.getParameter("depto"));
			} catch (NumberFormatException e) {
				error = true;
			}
			if ((nombre == null) || (apellidos == null) || (puesto == null)
					|| error) {
				System.out.println("Error en el empleado...");
				request.getRequestDispatcher("/empleados/errorEmpleado.jsp")
						.forward(request, response);
			} else {
				// Construimos y salvamos el nuevo empleado
				empleadoBO.newEmpleado(nombre, apellidos, puesto, date,
						nivelEd, sueldo, complemento, depto);
				request.getRequestDispatcher("/empleados/creadoEmpleado.jsp")
						.forward(request, response);
			}
			break;
		default:
			throw new ServletException("óAccin no reconocida o no especificada");
		}
	}

}
