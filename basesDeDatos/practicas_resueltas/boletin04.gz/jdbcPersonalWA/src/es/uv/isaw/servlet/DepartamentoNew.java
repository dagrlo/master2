package es.uv.isaw.servlet;

import java.io.IOException;
import java.util.TreeMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uv.isaw.bo.DepartamentoBoRemote;
import es.uv.isaw.bo.EmpleadoBoRemote;

/**
 * Servlet implementation class DepartamentoNew
 */
@WebServlet("/DepartamentoNew")
public class DepartamentoNew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB(mappedName = "EmpleadoBo")
	private EmpleadoBoRemote empleadoBO;
	@EJB(mappedName = "DepartamentoBo")
	private DepartamentoBoRemote departamentoBO;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DepartamentoNew() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		TreeMap<String, Integer> empleados;
		String nombre;
		int manager;

		String accion = request.getParameter("action");
		switch (accion) {
		case "form":
			empleados = empleadoBO.keysEmpleado();
			request.setAttribute("empleados", empleados);
			request.getRequestDispatcher("/departamentos/nuevoDepartamento.jsp")
					.forward(request, response);
			break;
		case "add":
			nombre = request.getParameter("nombre");
			manager = Integer.parseInt(request.getParameter("manager"));
			if (nombre == null) {
				System.out.println("Error en el departamento...");
				request.getRequestDispatcher(
						"/departamentos/errorDepartamento.jsp").forward(
						request, response);
			} else {
				departamentoBO.newDepartamento(nombre, manager);
				request.getRequestDispatcher(
						"/departamentos/creadoDepartamento.jsp").forward(
						request, response);
			}
			break;
		default:
			throw new ServletException(
					"DepartamentoNew: óaccin desconocida o no especificada.");
		}
	}

}
