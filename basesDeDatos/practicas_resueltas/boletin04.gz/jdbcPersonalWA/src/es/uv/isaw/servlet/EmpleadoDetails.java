package es.uv.isaw.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uv.isaw.bo.DepartamentoBoRemote;
import es.uv.isaw.bo.EmpleadoBoRemote;
import es.uv.isaw.dto.Empleado;

/**
 * Servlet implementation class EmpleadoDetails
 */
@WebServlet("/EmpleadoDetails")
public class EmpleadoDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB(mappedName = "EmpleadoBo")
	private EmpleadoBoRemote empleadoBO;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpleadoDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		int idEmpleado;
		
		String accion = request.getParameter("action");
		switch (accion) {
			case "form":request.getRequestDispatcher("/empleados/detallesEmpleado.jsp").forward(request, response);break;
			
			case "find":
				idEmpleado=Integer.parseInt(request.getParameter("codigo"));
				Empleado empleado=empleadoBO.findEmpleado(idEmpleado);	
				
				if (empleado.getIdEmpleado()==0){
					request.getRequestDispatcher("/empleados/errorDetails.jsp").forward(request, response);
				} else {
					request.setAttribute("empleado", empleado);
					request.getRequestDispatcher("/empleados/verEmpleado.jsp")
							.forward(request, response);	
				}
				
				break;
				
			default:throw new ServletException("óAccin no reconocida o no especificada");
		}
	}

}
