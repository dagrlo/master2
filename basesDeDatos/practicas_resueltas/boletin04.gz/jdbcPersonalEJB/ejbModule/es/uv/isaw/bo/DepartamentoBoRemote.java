package es.uv.isaw.bo;

import java.util.List;
import java.util.TreeMap;

import javax.ejb.Remote;

import es.uv.isaw.dto.Departamento;

@Remote
public interface DepartamentoBoRemote {
		
	public List<Departamento> listaDepartamentos();
	public Departamento findDepartamento(int id);
	public void newDepartamento(String nombre, int manager);
	public TreeMap<String, Integer> keysDepartamento();
	public void update(Departamento d);
}
