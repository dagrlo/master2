package es.uv.isaw.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import es.uv.isaw.dto.Empleado;

public class MysqlEmpleadoDao implements EmpleadoDAO {
	private static final String FINDBYID = "SELECT idEmpleado,nombre,apellidos,departamento,"
			+ "fechaContrato,puesto,nivelEducacion,"
			+ "sueldo,complemento"
			+ " FROM Empleados" + " WHERE idEmpleado = ?";
	private static final String INSERT = "INSERT INTO Empleados(nombre, apellidos, departamento, fechaContrato,"
			+ "puesto, nivelEducacion, sueldo, complemento)"
			+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String DELETE = "DELETE FROM Empleados WHERE idEmpleado = ?";
	private static final String READALL = "SELECT idEmpleado, nombre, apellidos, departamento,"
			+"fechaContrato,puesto, nivelEducacion, sueldo, complemento"+	" FROM Empleados" +
			" ORDER BY apellidos";
	private static final String FINDBYAPELLIDOS = "SELECT idEmpleado, nombre, apellidos, departamento,"
			+ "fechaContrato, puesto, nivelEducacion, sueldo, complemento"
			+ " FROM Empleados"
			+ " WHERE apellidos LIKE ?" + " ORDER BY apellidos";
	private static final String FINDBYDEPTO = "SELECT idEmpleado, nombre, apellidos, departamento,"
			+ "fechaContrato,puesto, nivelEducacion, sueldo, complemento"
			+ " FROM Empleados"
			+ " WHERE departamento = ?" + " ORDER BY apellidos";
	private static final String FINDKEYS = "SELECT idEmpleado, nombre, apellidos"
			+ " FROM Empleados";
	protected Connection con;

	public MysqlEmpleadoDao(Connection con) {
		this.con = con;
	}

	@Override
	public Empleado findById(int id) throws SQLException {
		Empleado empleado = new Empleado();
		PreparedStatement sqlQuery = con.prepareStatement(FINDBYID);
		sqlQuery.setInt(1, id);
		ResultSet rs = sqlQuery.executeQuery();
		rs.last();
		int rowcount = rs.getRow();
		if (rowcount == 1) {
			rs.first();
			empleado.setIdEmpleado(rs.getInt(1));
			empleado.setNombre(rs.getString(2));
			empleado.setApellidos(rs.getString(3));
			empleado.setDepartamento(rs.getInt(4));
			empleado.setFechaContrato(rs.getDate(5));
			empleado.setPuesto(rs.getString(6));
			empleado.setNivelEducacion(rs.getShort(7));
			empleado.setSueldo(rs.getFloat(8));
			empleado.setComplemento(rs.getFloat(9));
		}
		return empleado;
	}

	@Override
	public void persist(Empleado e) throws SQLException {
		PreparedStatement sqlQuery = con.prepareStatement(INSERT);

		sqlQuery.setString(1, e.getNombre());
		sqlQuery.setString(2, e.getApellidos());
		sqlQuery.setInt(3, e.getDepartamento());
		sqlQuery.setDate(4, (java.sql.Date) e.getFechaContrato());
		sqlQuery.setString(5, e.getPuesto());
		sqlQuery.setInt(6, e.getNivelEducacion());
		sqlQuery.setDouble(7, e.getSueldo());
		sqlQuery.setDouble(8, e.getComplemento());
		sqlQuery.executeUpdate();
		con.commit();

	}

	@Override
	public void remove(Empleado e) throws SQLException {
		PreparedStatement sqlQuery = con.prepareStatement(DELETE);
		sqlQuery.setInt(1, e.getIdEmpleado());
		sqlQuery.executeUpdate();
	}

	@Override
	public List<Empleado> getAllEmpleados() throws SQLException {
		List<Empleado> empleados = new ArrayList<Empleado>();

		PreparedStatement sqlQuery = con.prepareStatement(READALL);

		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			Empleado empleado = new Empleado();
			empleado.setIdEmpleado(rs.getInt(1));
			empleado.setNombre(rs.getString(2));
			empleado.setApellidos(rs.getString(3));
			empleado.setDepartamento(rs.getInt(4));
			//System.out.println("date "+rs.getString(5));
			//java.util.Date uDate = rs.getDate(5);
			//java.sql.Date sDate  = new java.sql.Date(uDate.getTime());
			empleado.setFechaContrato(rs.getDate(5));
			empleado.setPuesto(rs.getString(6));
			empleado.setNivelEducacion(rs.getShort(7));
			empleado.setSueldo(rs.getFloat(8));
			empleado.setComplemento(rs.getFloat(9));

			empleados.add(empleado);
		}
		return empleados;
	}

	@Override
	public List<Empleado> findEmpleadoByApellidos(String apellidos)
			throws SQLException {
		List<Empleado> empleados = new ArrayList<Empleado>();

		PreparedStatement sqlQuery = con.prepareStatement(FINDBYAPELLIDOS);
		sqlQuery.setString(1, apellidos);

		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			Empleado empleado = new Empleado();
			empleado.setIdEmpleado(rs.getInt(1));
			empleado.setNombre(rs.getString(2));
			empleado.setApellidos(rs.getString(3));
			empleado.setDepartamento(rs.getInt(4));
			empleado.setFechaContrato(rs.getDate(5));
			empleado.setPuesto(rs.getString(6));
			empleado.setNivelEducacion(rs.getShort(7));
			empleado.setSueldo(rs.getFloat(8));
			empleado.setComplemento(rs.getFloat(9));
			empleados.add(empleado);
		}
		return empleados;

	}
	@Override
	public List<Empleado> findEmpleadosByDepto(int id) throws SQLException {
		List<Empleado> empleados = new ArrayList<Empleado>();
		PreparedStatement sqlQuery = con.prepareStatement(FINDBYDEPTO);
		sqlQuery.setInt(1, id);
		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			Empleado empleado = new Empleado();
			empleado.setIdEmpleado(rs.getInt(1));
			empleado.setNombre(rs.getString(2));
			empleado.setApellidos(rs.getString(3));
			empleado.setDepartamento(rs.getInt(4));
			empleado.setFechaContrato(rs.getDate(5));
			empleado.setPuesto(rs.getString(6));
			empleado.setNivelEducacion(rs.getShort(7));
			empleado.setSueldo(rs.getFloat(8));
			empleado.setComplemento(rs.getFloat(9));
			empleados.add(empleado);
		}
		return empleados;
	}
	@Override
	public TreeMap<String, Integer> keysEmpleado() throws SQLException {
		String nombre;
		int id;
		TreeMap<String, Integer> keyEmp = new TreeMap<String, Integer>();

		PreparedStatement sqlQuery = con.prepareStatement(FINDKEYS);
		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			nombre = rs.getString("apellidos") + ", " + rs.getString("nombre");
			id = rs.getInt("idEmpleado");
			keyEmp.put(nombre, id);
		}
		return keyEmp;
	}

}
