package es.uv.isaw.bo;

import java.sql.Date;
import java.util.List;
import java.util.TreeMap;

import javax.ejb.Remote;

import es.uv.isaw.dto.Empleado;

@Remote
public interface EmpleadoBoRemote {
	List<Empleado> listaEmpleados();
	public Empleado findEmpleado(int id);
	public List<Empleado> buscarEmpleado(String apellidos);
	public void newEmpleado(String nombre, String apellidos, String puesto,
	Date date, Short nivelEducacion, float sueldo,
	float complemento, int depto);
	public TreeMap<String, Integer> keysEmpleado();
	public List<Empleado> findEmpleadosByDepto(int id);
}
