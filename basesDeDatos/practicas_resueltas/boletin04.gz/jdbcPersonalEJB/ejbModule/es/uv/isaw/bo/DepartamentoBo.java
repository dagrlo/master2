package es.uv.isaw.bo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.Stateless;

import com.sun.appserv.jdbc.DataSource;

import es.uv.isaw.dao.MySQLDepartamentoDao;
import es.uv.isaw.dto.Departamento;
import es.uv.isaw.util.FinalString;

/**
 * Session Bean implementation class DepartamentoBo
 */
@Stateless(mappedName = "DepartamentoBo")
// @LocalBean
public class DepartamentoBo implements DepartamentoBoRemote {

	@Resource(lookup = "jdbc/empresapool")
	private DataSource ds;
	private Connection con;
	private MySQLDepartamentoDao ddao = null;

	public DepartamentoBo() {
		// TODO Auto-generated constructor stub
	}

	@PostConstruct
	public void inicia() {
		try {
			con = ds.getConnection();
			ddao = new MySQLDepartamentoDao(con);
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en PostConstruct");
			e.printStackTrace();
		}
	}

	@PreDestroy
	public void finaliza() {
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en PreDestroy");
			e.printStackTrace();
		}
	}

	@Override
	public List<Departamento> listaDepartamentos() {
		List<Departamento> departamentos = null;
		try {
			departamentos = ddao.getAllDepartamentos();
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en listaDepartamentos");
			e.printStackTrace();
		}
		return departamentos;
	}

	@Override
	public Departamento findDepartamento(int id) {
		Departamento departamento = null;
		try {
			departamento = ddao.findById(id);
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en findDepartamento");
			e.printStackTrace();
		}
		return departamento;
	}

	@Override 
	public void update(Departamento d){
		try{
			ddao.update(d);
		}catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en newDepartamento");
			e.printStackTrace();
		}
	}
	
	@Override
	public void newDepartamento(String nombre, int manager) {
		Departamento nuevo = new Departamento();
		nuevo.setNombre(FinalString.arregla(nombre));
		nuevo.setManager(manager);
		try {
			ddao.persist(nuevo);
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en newDepartamento");
			e.printStackTrace();
		}
	}

	@Override
	public TreeMap<String, Integer> keysDepartamento() {
		TreeMap<String, Integer> keyDepto = new TreeMap<String, Integer>();
		try {
			keyDepto = ddao.keysDepartamento();
		} catch (SQLException e) {
			System.out.println("DepartamentoBo: Error en keyDepartamento");
			e.printStackTrace();
		}
		return keyDepto;
	}

}
