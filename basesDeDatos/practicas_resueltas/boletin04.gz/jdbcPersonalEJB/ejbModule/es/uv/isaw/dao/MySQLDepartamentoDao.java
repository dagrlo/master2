package es.uv.isaw.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import es.uv.isaw.dto.Departamento;

public class MySQLDepartamentoDao implements DepartamentoDao {
	private static String FINDBYID = "SELECT idDepartamento, nombre, manager"
			+ " FROM Departamentos" + " WHERE idDepartamento = ?";
	private static String INSERT = "INSERT INTO Departamentos(nombre, manager) "
			+ "VALUES (?, ?)";
	private static String DELETE = "DELETE FROM Departamentos"
			+ " WHERE idDepartamento = ?";
	private static String READALL = "SELECT idDepartamento, nombre, manager"
			+ " FROM Departamentos" + " ORDER BY nombre";
	private static String FINDKEYS = "SELECT idDepartamento, nombre"
			+ " FROM Departamentos;";

	private static String UPDATE = "UPDATE departamentos SET nombre=?, manager=?"
			+ " WHERE idDepartamento=?";

	protected Connection con;

	public MySQLDepartamentoDao(Connection con) {
		this.con = con;
	}

	@Override
	public Departamento findById(int id) throws SQLException {
		Departamento departamento = new Departamento();

		PreparedStatement sqlQuery = con.prepareStatement(FINDBYID);
		sqlQuery.setInt(1, id);
		ResultSet rs = sqlQuery.executeQuery();
		rs.last();
		int rowcount = rs.getRow();
		if (rowcount == 1) {
			rs.first();
			departamento.setIdDepartamento(rs.getInt(1));
			departamento.setNombre(rs.getString(2));
			departamento.setManager(rs.getInt(3));
		}
		return departamento;
	}

	@Override
	public void persist(Departamento d) throws SQLException {
		PreparedStatement sqlQuery = con.prepareStatement(INSERT);
		sqlQuery.setString(1, d.getNombre());
		sqlQuery.setInt(2, d.getManager());
		sqlQuery.executeUpdate();
		con.commit();
	}
	
	@Override
	public void update(Departamento d) throws SQLException{
		PreparedStatement sqlQuery=con.prepareStatement(UPDATE);
		sqlQuery.setString(1, d.getNombre());
		sqlQuery.setInt(2, d.getManager());
		sqlQuery.setInt(3, d.getIdDepartamento());
		sqlQuery.executeUpdate();
		con.commit();
	}

	@Override
	public void remove(Departamento d) throws SQLException {
		PreparedStatement sqlQuery = con.prepareStatement(DELETE);
		sqlQuery.setInt(1, d.getIdDepartamento());
		sqlQuery.executeUpdate();
	}

	@Override
	public List<Departamento> getAllDepartamentos() throws SQLException {
		List<Departamento> departamentos = new ArrayList<Departamento>();

		PreparedStatement sqlQuery = con.prepareStatement(READALL);
		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			Departamento departamento = new Departamento();
			departamento.setIdDepartamento(rs.getInt(1));
			departamento.setNombre(rs.getString(2));
			departamento.setManager(rs.getInt(3));
			departamentos.add(departamento);
		}
		return departamentos;
	}

	@Override
	public TreeMap<String, Integer> keysDepartamento() throws SQLException {
		TreeMap<String, Integer> keyEmp = new TreeMap<String, Integer>();

		PreparedStatement sqlQuery = con.prepareStatement(FINDKEYS);
		ResultSet rs = sqlQuery.executeQuery();
		rs.beforeFirst();
		while (rs.next()) {
			keyEmp.put(rs.getString("nombre"), rs.getInt("idDepartamento"));
		}
		return keyEmp;
	}
}
