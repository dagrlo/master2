package es.uv.isaw.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.TreeMap;

import es.uv.isaw.dto.Empleado;

public interface EmpleadoDAO {
		
	public Empleado findById(int id) throws SQLException;
	public void persist(Empleado e) throws SQLException;
	public void remove(Empleado e) throws SQLException;
	public List<Empleado> getAllEmpleados() throws SQLException;
	public List<Empleado> findEmpleadoByApellidos(String apellidos) throws SQLException;
	public List<Empleado> findEmpleadosByDepto(int id) throws SQLException;
	public TreeMap<String, Integer> keysEmpleado() throws SQLException;

}
