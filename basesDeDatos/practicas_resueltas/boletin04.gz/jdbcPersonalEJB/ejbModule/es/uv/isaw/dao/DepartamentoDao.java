package es.uv.isaw.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.TreeMap;

import es.uv.isaw.dto.Departamento;

public interface DepartamentoDao {
		
	public Departamento findById(int id) throws SQLException;
	public void persist(Departamento d) throws SQLException;
	public void remove(Departamento d) throws SQLException;
	public List<Departamento> getAllDepartamentos() throws SQLException;
	public TreeMap<String, Integer> keysDepartamento() throws SQLException;
	
	public void update(Departamento d) throws SQLException;
}
