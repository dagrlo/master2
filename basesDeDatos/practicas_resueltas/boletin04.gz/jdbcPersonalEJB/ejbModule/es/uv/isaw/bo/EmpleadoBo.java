package es.uv.isaw.bo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.Stateless;

import com.sun.appserv.jdbc.DataSource;

import es.uv.isaw.dao.MysqlEmpleadoDao;
import es.uv.isaw.dto.Empleado;
import es.uv.isaw.util.FinalString;

/**
 * Session Bean implementation class EmpleadoBo
 */
@Stateless(mappedName = "EmpleadoBo")
// @LocalBean
public class EmpleadoBo implements EmpleadoBoRemote {

	@Resource(lookup = "jdbc/empresapool")
	private DataSource ds;
	private Connection con;
	private MysqlEmpleadoDao edao = null;

	public EmpleadoBo() {
		// TODO Auto-generated constructor stub
	}

	@PostConstruct
	public void inicia() {
		try {
			con = ds.getConnection();
			edao = new MysqlEmpleadoDao(con);
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en PostConstruct");
			e.printStackTrace();
		}
	}

	@PreDestroy
	public void finaliza() {
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en PreDestroy");
			e.printStackTrace();
		}
	}

	@Override
	public List<Empleado> listaEmpleados() {
		List<Empleado> empleados = null;
		try {
			empleados = edao.getAllEmpleados();
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en listaEmpleados");
			e.printStackTrace();
		}
		return empleados;

	}

	@Override
	public Empleado findEmpleado(int id) {
		Empleado empleado = null;
		try {
			empleado = edao.findById(id);
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en findEmpleado");
			e.printStackTrace();
		}
		return empleado;
	}

	@Override
	public List<Empleado> buscarEmpleado(String apellidos) {
		List<Empleado> empleados = null;
		// Adaptamos el string y concatenamos el comodin al final
		apellidos = FinalString.arregla(apellidos) + " %";
		try {
			empleados = edao.findEmpleadoByApellidos(apellidos);
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en buscarEmpleado");
			e.printStackTrace();
		}
		return empleados;
	}

	@Override
	public void newEmpleado(String nombre, String apellidos, String puesto,
			Date date, Short nivelEducacion, float sueldo, float complemento,
			int depto) {
		Empleado nuevo = new Empleado();
		nuevo.setNombre(FinalString.arregla(nombre));
		nuevo.setApellidos(FinalString.arregla(apellidos));
		nuevo.setPuesto(puesto);
		nuevo.setFechaContrato(date);
		nuevo.setNivelEducacion(nivelEducacion);
		nuevo.setSueldo(sueldo);
		nuevo.setComplemento(complemento);
		nuevo.setDepartamento(depto);
		try {
			// Salvamos el nuevo empleado
			edao.persist(nuevo);
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en nuevoEmpleado");
			e.printStackTrace();
		}
	}

	@Override
	public TreeMap<String, Integer> keysEmpleado() {
		TreeMap<String, Integer> keyEmp = new TreeMap<String, Integer>();
		try {
			keyEmp = edao.keysEmpleado();
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en keysEmpleado");
			e.printStackTrace();
		}
		return keyEmp;

	}

	@Override
	public List<Empleado> findEmpleadosByDepto(int id) {
		List<Empleado> empleados = null;
		try {
			empleados = edao.findEmpleadosByDepto(id);
		} catch (SQLException e) {
			System.out.println("EmpleadoBo: Error en findEmpleadosByDepto");
			e.printStackTrace();
		}
		return empleados;
	}

}
