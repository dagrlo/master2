package sssi.tasi.personal.bo;

import java.util.List;
import java.util.TreeMap;

import javax.ejb.Remote;

import sssi.tasi.personal.entity.Departamento;
import sssi.tasi.personal.entity.Empleado;

@Remote
public interface DepartamentoBoRemote {
	public List<Departamento> listaDepartamentos();
	public Departamento findDepartamento(int id);
	public void newDepartamento(String nombre, int manager);
	public TreeMap<String, Integer> keysDepartamento();
	public List<Empleado> findEmpleadosByDepto(int id);
	public Empleado getManager(int id);
	public void update(Departamento d);	
	
}
