package sssi.tasi.personal.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the empleados database table.
 * 
 */
@Entity
@Table(name = "empleados")
@NamedQueries({
	@NamedQuery(name = "Empleado.findAll", query = "SELECT e "
			+ " FROM Empleado e " + " ORDER BY e.apellidos"),
	@NamedQuery(name = "Empleado.findByName", query = "SELECT e FROM Empleado e "
			+ " WHERE e.apellidos LIKE :apellidos "
			+ " ORDER BY e.apellidos") })
public class Empleado implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idEmpleado;

	private String apellidos;

	private BigDecimal complemento;

	@Temporal(TemporalType.DATE)
	private Date fechaContrato;

	private short nivelEducacion;

	private String nombre;

	private String puesto;

	private BigDecimal sueldo;

	// bi-directional many-to-one association to Departamento
	@ManyToOne
	@JoinColumn(name = "departamento")
	private Departamento departamento;

	public Empleado() {
	}

	public int getIdEmpleado() {
		return this.idEmpleado;
	}

	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}

	public String getApellidos() {
		return this.apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public BigDecimal getComplemento() {
		return this.complemento;
	}

	public void setComplemento(BigDecimal complemento) {
		this.complemento = complemento;
	}

	public Date getFechaContrato() {
		return this.fechaContrato;
	}

	public void setFechaContrato(Date fechaContrato) {
		this.fechaContrato = fechaContrato;
	}

	public short getNivelEducacion() {
		return this.nivelEducacion;
	}

	public void setNivelEducacion(short nivelEducacion) {
		this.nivelEducacion = nivelEducacion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPuesto() {
		return this.puesto;
	}

	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}

	public BigDecimal getSueldo() {
		return this.sueldo;
	}

	public void setSueldo(BigDecimal sueldo) {
		this.sueldo = sueldo;
	}

	public Departamento getDepartamento() {
		return this.departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}

}