package sssi.tasi.personal.bo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

import javax.ejb.Remote;

import sssi.tasi.personal.entity.Empleado;

@Remote
public interface EmpleadoBoRemote {
	List<Empleado> listaEmpleados();
	public Empleado findEmpleado(int id);
	public List<Empleado> buscarEmpleado(String apellidos);
	public void newEmpleado(String nombre, String apellidos, String puesto,
	Date date, Short nivelEducacion, BigDecimal sueldo,
	BigDecimal complemento, int depto);
	public TreeMap<String, Integer> keysEmpleado();
	public void update(Empleado o);
}
