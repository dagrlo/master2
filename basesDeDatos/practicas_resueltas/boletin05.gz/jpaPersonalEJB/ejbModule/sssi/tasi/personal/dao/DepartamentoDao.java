package sssi.tasi.personal.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import sssi.tasi.personal.entity.Departamento;

public class DepartamentoDao extends JpaDao<Integer, Departamento> {
	public DepartamentoDao(EntityManager em) {
		super(em);
	}

	public List<Departamento> getAllDepartamentos() {
		TypedQuery<Departamento> query = em.createNamedQuery(
				"Departamento.findAll", Departamento.class);
		return query.getResultList();
	} 
	
	public void update(Departamento d){
		
		em.merge(d);
		em.flush();  //NO VA!!!
		
		
	}
}
