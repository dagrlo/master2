package sssi.tasi.personal.bo;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import sssi.tasi.personal.dao.DepartamentoDao;
import sssi.tasi.personal.dao.EmpleadoDao;
import sssi.tasi.personal.entity.Departamento;
import sssi.tasi.personal.entity.Empleado;
import sssi.tasi.personal.util.FinalString;

/**
 * Session Bean implementation class DepartamentoBo
 */
@Stateless
public class DepartamentoBo implements DepartamentoBoRemote {

	@PersistenceUnit(name = "personalPersistenceUnit")
	private EntityManagerFactory emf;
	private EntityManager em;
	private DepartamentoDao ddao;
	private EmpleadoDao edao;

	@PostConstruct
	public void init() {
		em = emf.createEntityManager();
		ddao = new DepartamentoDao(em);
		edao = new EmpleadoDao(em);
	}

	@PreDestroy
	public void finaliza() {
		em.close();
	}

	public DepartamentoBo() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Departamento> listaDepartamentos() {
		List<Departamento> departamentos = ddao.getAllDepartamentos();
		return departamentos;
	}

	@Override
	public Departamento findDepartamento(int id) {
		return ddao.findById(id);
	}

	@Override
	public TreeMap<String, Integer> keysDepartamento() {
		TreeMap<String, Integer> keyDepto = new TreeMap<String, Integer>();

		List<Departamento> departamentos = ddao.getAllDepartamentos();
		for (Departamento depto : departamentos) {
			keyDepto.put(depto.getNombre(), depto.getIdDepartamento());
		}
		return keyDepto;
	}

	@Override
	public void update(Departamento d){
		ddao.update(d);
	}
	
	@Override
	public void newDepartamento(String nombre, int m) {
		Departamento nuevo = new Departamento();
		nuevo.setNombre(FinalString.arregla(nombre));
		/*
		 * Buscamos el manager del departamento y lo asignamos
		 */
		Empleado manager = edao.findById(m);
		nuevo.setManager(manager);
		/*
		 * Creamos el conjunto de empleados del departamento.
		 */
		List<Empleado> empleados = new ArrayList<Empleado>();
		nuevo.setEmpleados(empleados);
		/*
		 * Damos de baja al empleado de su antiguo departamentos
		 */
		manager.getDepartamento().getEmpleados().remove(manager);
		/*
		 * Asignamos el manager al nuevo departamento. Es necesario actualizar
		 * ambos extremos de la asociacion.
		 */
		empleados.add(manager);
		manager.setDepartamento(nuevo);
		/*
		 * Guardamos el nuevo departamento
		 */
		ddao.persist(nuevo);
	}

	@Override
	public Empleado getManager(int id){
		Departamento dep=ddao.findById(id);
		return dep.getManager();
	}
	
	@Override
	public List<Empleado> findEmpleadosByDepto(int id) {
		List<Empleado> empleados = new ArrayList<Empleado>();
		Departamento depto = ddao.findById(id);
		for (Empleado emp : depto.getEmpleados()) {
			empleados.add(emp);
		}
		return empleados;
	}

}
