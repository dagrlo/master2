package sssi.tasi.personal.bo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import sssi.tasi.personal.dao.DepartamentoDao;
import sssi.tasi.personal.dao.EmpleadoDao;
import sssi.tasi.personal.entity.Departamento;
import sssi.tasi.personal.entity.Empleado;
import sssi.tasi.personal.util.FinalString;

/**
 * Session Bean implementation class EmpleadoBo
 */
@Stateless
public class EmpleadoBo implements EmpleadoBoRemote {

	@PersistenceContext(name = "personalPersistenceUnit")
	private EntityManager em;
	private EmpleadoDao edao;
	private DepartamentoDao ddao;

	@PostConstruct
	public void init() {
		edao = new EmpleadoDao(em);
		ddao = new DepartamentoDao(em);
	}

	@PreDestroy
	public void finaliza() {
		em.close();
	}

	public EmpleadoBo() {
		// TODO Auto-generated constructor stub
	}
	
	public void update(Empleado o){
		edao.update(o);
	}

	@Override
	public List<Empleado> listaEmpleados() {
		List<Empleado> empleados = edao.getAllEmpleados();
		return empleados;
	}

	@Override
	public Empleado findEmpleado(int id) {
		return edao.findById(id);
	}

	@Override
	public List<Empleado> buscarEmpleado(String apellidos) {
		// Adaptamos el string y concatenamos el comodin al final
		apellidos = FinalString.arregla(apellidos) + " %";
		return edao.findEmpleadoByName(apellidos);
	}

	@Override
	public void newEmpleado(String nombre, String apellidos, String puesto,
			Date date, Short nivelEducacion, BigDecimal sueldo,
			BigDecimal complemento, int depto) {
		Empleado nuevo = new Empleado();
		nuevo.setNombre(FinalString.arregla(nombre));
		nuevo.setApellidos(FinalString.arregla(apellidos));
		nuevo.setPuesto(puesto);
		nuevo.setFechaContrato(date);
		nuevo.setNivelEducacion(nivelEducacion);
		nuevo.setSueldo(sueldo);
		nuevo.setComplemento(complemento);
		/*
		 * Localizamos el departamento.
		 */
		Departamento departamento = ddao.findById(depto);
		nuevo.setDepartamento(departamento);
		departamento.getEmpleados().add(nuevo);
		// Salvamos el nuevo empleado
		edao.persist(nuevo);
	}

	@Override
	public TreeMap<String, Integer> keysEmpleado() {
		String nomCompleto;
		TreeMap<String, Integer> keyEmp = new TreeMap<String, Integer>();
		List<Empleado> empleados = edao.getAllEmpleados();
		for (Empleado emp : empleados) {
			nomCompleto = emp.getApellidos() + ", " + emp.getNombre();
			keyEmp.put(nomCompleto, emp.getIdEmpleado());
		}
		return keyEmp;
	}

}
