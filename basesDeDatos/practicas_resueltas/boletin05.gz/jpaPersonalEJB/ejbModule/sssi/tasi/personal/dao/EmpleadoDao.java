package sssi.tasi.personal.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import sssi.tasi.personal.entity.Empleado;

public class EmpleadoDao extends JpaDao<Integer, Empleado> {

	public EmpleadoDao(EntityManager em) {
		super(em);
	}

	public void update(Empleado o){
	    em.merge(o);	
		em.flush();
	}
	
	public List<Empleado> getAllEmpleados() {
		TypedQuery<Empleado> query = em.createNamedQuery("Empleado.findAll",
				Empleado.class);
		return query.getResultList();
	}

	public List<Empleado> findEmpleadoByName(String apellidos) {
		TypedQuery<Empleado> query = em.createNamedQuery("Empleado.findByName",
				Empleado.class);
		query.setParameter("apellidos", apellidos);
		return query.getResultList();
	}
}
