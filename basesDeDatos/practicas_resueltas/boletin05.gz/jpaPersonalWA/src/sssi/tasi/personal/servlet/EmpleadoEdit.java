package sssi.tasi.personal.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Calendar;
import java.util.TreeMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import sssi.tasi.personal.bo.DepartamentoBoRemote;
import sssi.tasi.personal.bo.EmpleadoBoRemote;
import sssi.tasi.personal.entity.Departamento;
import sssi.tasi.personal.entity.Empleado;



/**
 * Servlet implementation class EmpleadoEdit
 */
@WebServlet("/EmpleadoEdit")
public class EmpleadoEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	private EmpleadoBoRemote empleadoBO;
	@EJB
	private DepartamentoBoRemote departamentoBO;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpleadoEdit() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
    	String accion = request.getParameter("action");
    	String codigo;
    	String nombre, apellidos, puesto, ano, mes, dia;
		Date date;
		Short nivelEd = 0;
		float sueldo = 0, complemento = 0;
		int depto = 0;
		boolean error=false;
		TreeMap<String, Integer> departamentos = null;
    	Empleado empleado;
    	
    	
    	switch (accion) {
    	
		case "form":			
		
				request.getRequestDispatcher("/empleados/buscarEmpleados3.jsp").forward(request, response);
			break;
			
		case "find":
			codigo = request.getParameter("codigo");
			departamentos = departamentoBO.keysDepartamento();
			empleado=empleadoBO.findEmpleado(Integer.parseInt(codigo));
			if (empleado==null)
			{
				request.getRequestDispatcher("/empleados/errorDetails.jsp").forward(request, response);					
			} else {					
				request.setAttribute("empleado", empleado);
				request.setAttribute("departamentos", departamentos);
				request.getRequestDispatcher("/empleados/empleadoEditor.jsp")
				.forward(request, response);
			}
			
		break;
		
		case "edit":
			codigo = request.getParameter("codigo");
			
			
			nombre = request.getParameter("nombre");
			apellidos = request.getParameter("apellidos");
			puesto = request.getParameter("puesto");
			ano = request.getParameter("ano");
			mes = request.getParameter("mes");
			dia = request.getParameter("dia");
			Calendar calendar = Calendar.getInstance();
			java.util.Date currentDate = calendar.getTime();
			date = new java.sql.Date(currentDate.getTime());
			try {
				nivelEd = Short.parseShort(request
						.getParameter("nivelEducacion"));
				sueldo = Float.parseFloat(request.getParameter("sueldo"));
				complemento = Float.parseFloat(request
						.getParameter("complemento"));
				depto = Integer.parseInt(request.getParameter("depto"));
			} catch (NumberFormatException e) {
				error = true;
			}
			if ((nombre == null) || (apellidos == null) || (puesto == null)
					|| error) {
				System.out.println("Error en el empleado...");
				request.getRequestDispatcher("/empleados/errorEmpleado.jsp")
						.forward(request, response);
			} else {
				System.out.println("e:"+codigo);
				empleado=empleadoBO.findEmpleado(Integer.parseInt(codigo));
				empleado.setApellidos(apellidos);
				empleado.setComplemento(new BigDecimal(Float.toString(complemento)));
				Departamento departamento=departamentoBO.findDepartamento(depto);
				empleado.setDepartamento(departamento);
				empleado.setFechaContrato(date);
				empleado.setIdEmpleado(Integer.parseInt(codigo));
				empleado.setNivelEducacion(nivelEd);				
				empleado.setNombre(nombre);
				empleado.setPuesto(puesto);
				empleado.setSueldo(new BigDecimal(Float.toString(sueldo)));
				
				empleadoBO.update(empleado);
				
				request.getRequestDispatcher("/empleados/creadoEmpleado.jsp")
				.forward(request, response);
				
				
			}
			break;
		
		default:
			throw new ServletException("óAccin no reconocida o no especificada");
    	}
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
