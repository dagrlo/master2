package sssi.tasi.personal.servlet;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sssi.tasi.personal.bo.DepartamentoBoRemote;
import sssi.tasi.personal.bo.EmpleadoBoRemote;
import sssi.tasi.personal.entity.Empleado;


/**
 * Servlet implementation class EmpleadoFindByName
 */
@WebServlet("/EmpleadoFindByName")
public class EmpleadoFindByName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	private EmpleadoBoRemote empleadoBO;
	@EJB
	private DepartamentoBoRemote departamentoBO;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmpleadoFindByName() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<Empleado> empleados;
		String apellidos;
		String accion = request.getParameter("action");
		// Bucle de óseleccin de la óaccin
		switch (accion) {
		case "form":
			request.getRequestDispatcher("/empleados/buscarEmpleados.jsp")
					.forward(request, response);
			break;
		case "find":
			apellidos = request.getParameter("apellidos");
			empleados = empleadoBO.buscarEmpleado(apellidos);
			request.setAttribute("empleados", empleados);
			request.getRequestDispatcher("/empleados/listaEmpleados.jsp")
					.forward(request, response);
			break;
		default:
			throw new ServletException("óAccin no reconocida o no especificada");
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
