package sssi.tasi.personal.servlet;

import java.io.IOException;
import java.util.TreeMap;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sssi.tasi.personal.bo.DepartamentoBoRemote;
import sssi.tasi.personal.bo.EmpleadoBoRemote;
import sssi.tasi.personal.entity.Departamento;
import sssi.tasi.personal.entity.Empleado;

/**
 * Servlet implementation class DepartamentoManager
 */
@WebServlet("/DepartamentoManager")
public class DepartamentoManager extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	private EmpleadoBoRemote empleadoBO;
	@EJB
	private DepartamentoBoRemote departamentoBO;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepartamentoManager() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
    	
    	TreeMap<String, Integer> departamentos;
    	Integer id;
    	String accion = request.getParameter("action");
    	
    	switch (accion) {
    	
			case "lista":departamentos = departamentoBO.keysDepartamento();
						 request.setAttribute("departamentos", departamentos);
						 request.getRequestDispatcher("/departamentos/selDepartamento.jsp").forward(request, response);
				break;
				
			case "continua":
					id=Integer.parseInt(request.getParameter("depto"));
					Empleado manager=departamentoBO.getManager(id);
					TreeMap<String, Integer> empleados=empleadoBO.keysEmpleado();					
					request.setAttribute("manager", manager);
					request.setAttribute("empleados", empleados);
					request.setAttribute("deptoId", id);
					System.out.println("sel man");
					request.getRequestDispatcher("/departamentos/selectManager.jsp").forward(request, response);
				break;
			case "actualiza":
					id=Integer.parseInt(request.getParameter("nuevoManager"));
					Integer deptoId=Integer.parseInt(request.getParameter("deptoId"));
					Empleado newManager=empleadoBO.findEmpleado(id);
					Departamento dep=departamentoBO.findDepartamento(deptoId);
					System.out.println("new:"+newManager.getNombre());
					dep.setManager(newManager); //NO ACTUALIZA NADA!!!
					
					departamentoBO.update(dep); //da error en el flush.
					newManager.getDepartamento().getEmpleados().remove(newManager);
					
					
				break;
				
			default:
				throw new ServletException("óAccin no reconocida o no especificada");
    	}
    	
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
