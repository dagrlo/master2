package sssi.tasi.personal.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sssi.tasi.personal.bo.EmpleadoBoRemote;
import sssi.tasi.personal.entity.Empleado;

/**
 * Servlet implementation class EmpleadoDetails
 */
@WebServlet("/EmpleadoDetails")
public class EmpleadoDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	private EmpleadoBoRemote empleadoBO;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpleadoDetails() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
    	String accion = request.getParameter("action");
    	String codigo;
    	Empleado empleado;
    	
    	switch (accion) {
    	
		case "form":request.getRequestDispatcher("/empleados/buscarEmpleados2.jsp").forward(request, response);break;
		
		case "find":
				codigo = request.getParameter("codigo");
				empleado=empleadoBO.findEmpleado(Integer.parseInt(codigo));
				if (empleado==null)
				{
					request.getRequestDispatcher("/empleados/errorDetails.jsp").forward(request, response);					
				} else {					
					request.setAttribute("empleado", empleado);
					request.getRequestDispatcher("/empleados/empleadoDetails.jsp")
					.forward(request, response);
				}
				
			break;
		
		default:
			throw new ServletException("óAccin no reconocida o no especificada");
    	}
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
